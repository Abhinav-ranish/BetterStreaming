'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';

type Title = {
  id: string;
  name: string;
  imageUrl?: string;
  service: {
    name: string;
  };
};

export default function BrowsePage() {
  const [titles, setTitles] = useState<Title[]>([]);

  useEffect(() => {
    const fetchTitles = async () => {
      const res = await fetch('/api/titles');
      const data = await res.json();
      setTitles(data.titles);
    };

    fetchTitles();
  }, []);

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">🎬 All Shows</h1>
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
        {titles.map((t) => (
          <div key={t.id} className="bg-white shadow-md rounded overflow-hidden flex flex-col">
            <img
              src={t.imageUrl || 'https://via.placeholder.com/300x170'}
              alt={t.name}
              className="w-full h-[170px] object-cover"
            />
            <div className="p-2 flex flex-col flex-grow justify-between">
              <div>
                <p className="font-semibold text-sm">{t.name}</p>
                <span className="text-xs text-gray-500">{t.service.name}</span>
              </div>
              <Link href={`/watch/${t.id}`}>
                <button className="mt-2 w-full px-3 py-1 bg-blue-600 text-white text-sm rounded hover:bg-blue-700">
                  ▶ Play
                </button>
              </Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
