import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';
import { verifyPassword } from '@/lib/auth';
import { sendOTP } from '@/lib/mail';

const prisma = new PrismaClient();

export async function POST(req: NextRequest) {
  const { email, password } = await req.json();

  const user = await prisma.user.findUnique({ where: { email } });
  if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 });

  const isValid = await verifyPassword(password, user.password);
  if (!isValid) return NextResponse.json({ error: 'Invalid credentials' }, { status: 401 });

  const otp = Math.floor(100000 + Math.random() * 900000).toString();

  await prisma.user.update({
    where: { email },
    data: { otp },
  });

  await sendOTP(email, otp);

  return NextResponse.json({ message: 'OTP sent' });
}
