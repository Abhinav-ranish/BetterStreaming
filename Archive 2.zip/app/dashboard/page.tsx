'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';




export default function DashboardPage() {
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState<any>(null);
  const router = useRouter();

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) {
      router.push('/register');
      return;
    }

    const fetchUser = async () => {
      const res = await fetch('/api/me', {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (res.ok) {
        const data = await res.json();
        setUser(data.user);
      } else {
        localStorage.removeItem('token');
        router.push('/register');
      }

      setLoading(false);
    };

    fetchUser();
  }, [router]);
  if (loading) return <div className="p-8">Loading...</div>;
    console.log('👤 Fetched user:', user);

  return (
    <div className="p-8 max-w-xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">🎉 Welcome to the Dashboard</h1>
      <p className="text-gray-700">
        You are now logged in as <strong>{user?.email || 'Unknown user'}</strong></p>
    <Link href="/browse" className="mt-6 inline-block bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700">
        🎬 Go to Browse Page
    </Link>
    </div>


  );
}
