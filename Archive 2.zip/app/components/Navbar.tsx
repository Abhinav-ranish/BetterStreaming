'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';

export default function Navbar() {
  const pathname = usePathname();

  const navLink = (href: string, label: string) => (
    <Link
      href={href}
      className={`px-3 py-2 rounded ${
        pathname === href ? 'bg-red-600 text-white' : 'text-gray-200 hover:text-white'
      }`}
    >
      {label}
    </Link>
  );

  return (
    <nav className="w-full bg-black text-white flex items-center justify-between px-6 py-3 shadow-md">
      <div className="text-xl font-bold">🎞️ BetterStreaming</div>
      <div className="flex gap-4">
        {navLink('/dashboard', 'Dashboard')}
        {navLink('/browse', 'Browse')}
        {navLink('/login', 'Login')}
      </div>
    </nav>
  );
}
