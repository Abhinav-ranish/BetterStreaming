// app/watch/[id]/page.tsx
'use client';

import { useEffect, useRef, useState } from 'react';
import WebTorrent from 'webtorrent';
import Link from 'next/link';

export default function WatchPage({ params }: { params: { id: string } }) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [title, setTitle] = useState('');
  const [streams, setStreams] = useState<any[]>([]);
  const [selectedIndex, setSelectedIndex] = useState(0);

  useEffect(() => {
    const client = new WebTorrent();

    const fetchAndStream = async () => {
      try {
        const res = await fetch(`/api/title/${params.id}/stream`);
        const data = await res.json();

        if (!data.streams || data.streams.length === 0) {
          setError('No streams available');
          setLoading(false);
          return;
        }

        setStreams(data.streams);
        const stream = data.streams[selectedIndex];
        setTitle(stream.title || 'Streaming');

        const magnet = `magnet:?xt=urn:btih:${stream.infoHash}`;

        client.add(magnet, (torrent) => {
          const file = torrent.files[stream.fileIdx || 0];

          file.renderTo(videoRef.current!, {
            autoplay: true,
          });

          setLoading(false);
        });
      } catch (err: any) {
        console.error(err);
        setError('Failed to load stream');
        setLoading(false);
      }
    };

    fetchAndStream();

    return () => client.destroy();
  }, [params.id, selectedIndex]);

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-xl font-bold">🎬 {title}</h1>
        <Link href="/browse" className="text-blue-600 hover:underline text-sm">
          ← Back to Browse
        </Link>
      </div>

      {streams.length > 1 && (
        <div className="mb-4">
          <label className="block mb-1 font-semibold">Select Quality:</label>
          <select
            className="border p-2 rounded"
            value={selectedIndex}
            onChange={(e) => setSelectedIndex(Number(e.target.value))}
          >
            {streams.map((s, idx) => (
              <option key={idx} value={idx}>
                {s.name?.replace(/\n/g, ' ')} ({s.title?.slice(0, 60)}...)
              </option>
            ))}
          </select>
        </div>
      )}

      {error && <p className="text-red-600">{error}</p>}
      {loading && <p className="text-gray-500">⏳ Loading stream...</p>}
      <video
        ref={videoRef}
        controls
        style={{ width: '100%', height: 'auto', background: '#000' }}
      ></video>
    </div>
  );
}